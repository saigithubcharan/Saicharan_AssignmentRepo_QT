//Implement a program to remove the first element from an array without using shift().

const arr1=[1,2,3,4,5,6];
arr1.splice(0,1);
console.log(arr1);