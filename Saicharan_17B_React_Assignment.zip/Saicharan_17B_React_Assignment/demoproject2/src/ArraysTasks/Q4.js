
//Create an array of integers and print the square of each element.
const numbers = [1, 2, 3, 4];
const squares = numbers.map(num => num * num);

console.log(squares);