///Create an array of numbers and print all the even-indexed  elements.

const numbers = [10, 20, 30, 40, 50, 60, 70];

for (let i = 0; i < numbers.length; i += 2) {
  console.log(numbers[i]);
}
