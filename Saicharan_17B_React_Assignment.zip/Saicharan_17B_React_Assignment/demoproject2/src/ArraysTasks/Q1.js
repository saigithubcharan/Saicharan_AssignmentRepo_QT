//Write a program to create an array of strings and print each element using a for loop.

const array=["apple","banana","papaya","Mango"];
for(let i=0;i<array.length;i++){
    console.log(array[i]);
}