//Create an object to represent a book. It should have properties: title author, pages, and isRead. Initialize it with appropriate values?

const book = {
    title: "To Kill a Mockingbird",
    author: "Harper Lee",
    pages: 281,
    isRead: true
};

console.log(book);